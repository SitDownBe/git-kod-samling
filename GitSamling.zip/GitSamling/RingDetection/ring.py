#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
'''
Assignment 2: Search String Replacement

Team Number: 68
Student Names: Fredrik Grape, Sebastian Grans
'''
import unittest
import networkx as nx
try:
    import matplotlib.pyplot as plt
    HAVE_PLT = True
except ImportError:
    HAVE_PLT = False
def ring(G):
    """
    Sig: graph G(node,edge) ==> boolean
    Pre: networkx version 1.11 undirected graph G
    Post: every nodes in G have attributes 'white', 'black' or 'gray'
    Example: 
        ring(g1) ==> False
        ring(g2) ==> True
    """   
    # mark all node as not yet visited.
    for i in G.nodes():
        # variant: len(G.nodes())-i
        nx.set_node_attributes(G, 'color', 'white')
    temp=False
    # make sure that all nodes are visited in case
    #  graph is not connected.
    for i in G.nodes():
        # variant: len(G.nodes())-i
        if nx.get_node_attributes(G, 'color')[i] is 'white': 
            if ring_visit(G,i):
                temp=True
                break
    return temp

def ring_visit(G,u):
    '''
    Sig: graph G(node,edge), node u ==> boolean
    Pre: networkx version 1.11 undirected graph G
    Post: every nodes in G have attributes 'white', 'black' or 'gray'
    Var: # of white nodes
    Example:
        ring_visit(G,u) ==> False
        ring_visit(G,u) ==> True
    '''
    counter=0
    # color a node gray that has just now been visited.
    G.node[u]['color']='gray'
    for i in list(G[u]):
        # variant: len(list(G[u]))-i
        if nx.get_node_attributes(G, 'color')[i] is 'gray':
            counter += 1
    # if a node has at least 2 neighbors and they are both gray,
    #   we must necessarily have gone in a circle.
    if counter>=2:
        return True
    else:
        for i in list(G[u]):
            # variant: len(list(G[u]))-i
            if nx.get_node_attributes(G, 'color')[i] is 'white':
                # return true all the way up if a circle
                #   has been found.
                if ring_visit(G,i):
                    return True
        # if a dead end is reached, color node black.
        G.node[u]['color']='black'

def ring_extended(G):
    """
    Sig: graph G(node,edge) ==> boolean, int[0..j-1]
    Pre: networkx version 1.11 undirected graph G
    Post: ringlist (defined below) contains a list with
            the nodes of a circle, if one exists.
    Example: 
        ring(g1) ==> False, []
        ring(g2) ==>  True, [3,7,8,6,3]
    """

    ringlist=[]

    # mark all nodes as not yet visited
    for i in G.nodes():
        # variant: len(G.nodes())-index(i)
        nx.set_node_attributes(G, 'color', 'white')

    temp=False
    # make sure that all nodes are visited in case
    #   graph is not connected. Also alter ringlist
    #   if a circle exists.
    for i in G.nodes():
        # variant: len(G.nodes())-index(i)
        if nx.get_node_attributes(G, 'color')[i] is 'white': 
            if ring_visit_extended(G,i,ringlist,None):
                temp=True
                break

    # make sure to only include the nodes of
    #   the circle.
    if ringlist:
        i=1
        while ringlist[i]!=ringlist[0]:
            # variant: j-i with j the index where the first element
            #           of ringlist first repeats itself.
            i += 1
        i += 1
        while i<len(ringlist):
            # variant: len(ringlist)-i
            ringlist.pop(i)

    return temp, ringlist

def ring_visit_extended(G,u,l,p):
    '''
    Sig: graph G(nodes,edges), node u, list l, node p ==> boolean
    Pre: networkx version 1.11 undirected graph G, empty list l,
            p parent node to u is None
    Post: l contains the nodes of a circle, may contain additional nodes
            outside of the circle
    Var: # of white nodes
    Example:
        ring_visit_extended(G,u,l,p) ==> True
        ring_visit_extended(G,u,l,p) ==> False
    '''
    counter=0

    # color a node gray that was just now visited
    G.node[u]['color']='gray'

    for i in list(G[u]):
        # variant: len(list(G[u]))-index(i)
        if nx.get_node_attributes(G, 'color')[i] is 'gray':
            counter += 1

    # if a node has at least 2 neighbors and they are both gray,
    #   we must necessarily have gone in a circle.
    if counter>=2:
        # if a circle has been encountered, add the node that ties
        #   the circle together.
        for i in list(G[u]):
            # variant: len(list(G[u]))-index(i)
            if nx.get_node_attributes(G,'color')[i] is 'gray' and i is not p:
                l.append(i)
                break
        l.append(u)
        return True
    else:
        for i in list(G[u]):
            # variant: len(list(G[u]))-index(i)
            if nx.get_node_attributes(G, 'color')[i] is 'white':
                # return true all the way up if a circle
                #   has been found and add the nodes visited
                #   on the way to l.
                if ring_visit_extended(G,i,l,u):
                    l.append(u)
                    return True

        # if a dead end is reached, color node black.
        G.node[u]['color']='black'
