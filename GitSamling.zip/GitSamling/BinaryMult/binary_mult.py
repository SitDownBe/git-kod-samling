#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
'''
Assignment 1: Binary Multiplication

Team Number: 68
Student Names: Fredrik Grape, Sebastian Grans
'''

def binary_mult(A,B):
	"""
    Sig:    int[0..n-1], int[0..n-1] ==> int[0..2*n-1]
    Pre:    A and B binary arrays of same length n
    Post:   An array C of length 2n containing the binary product of A times B   
    Example:    binary_mult([0,1,1],[1,0,0]) = [0,0,1,1,0,0]
    """

	n = (len(A)+len(B))/2

	bmult = binary_part(A,B)

	# Acquire the desired length 2n
	if len(bmult) != 2*n:
		while len(bmult)<2*n:
			# Invariant: value of bmult
			# Variant: 2*n - len(bmult)
			bmult.insert(0,0)
		while len(bmult)>2*n:
			# Invariant: value of bmult
			# Variant: len(bmult) - 2*n
			bmult.pop(0)

	return bmult


def binary_part(A,B):
	'''
    Sig:    int[0..n-1], int[0..n-1] ==> int[0..2*n-1]
    Pre:    A and B binary arrays of same length n
    Post:   An array C of unspecfied length containing the binary product of A times B
    Var:    n-1
    Example:    binary_part([0,0,1,0],[0,1,0,0] = [0,0,0,1,0,0,0])   
    '''

	n = (len(A)+len(B))/2
 
 	if n == 1:
 		# Base case
 		return [A[0]*B[0]]

 	else:

 		while (n&(n-1))!=0:
 			# Invariant: value of A and B
 			# Variant: 2^k - n for some integer k>0
 			A.insert(0,0)
 			B.insert(0,0)
 			n = (len(A)+len(B))/2

 		# Split the arrays into their high and low bits
 		Ah = A[:n/2]
 		Al = A[n/2:]
 		Bh = B[:n/2]
 		Bl = B[n/2:]

		# If xh and xl are the high and low bits of x, and yh and yl
        # are the high and low bits of y respectively, then:
        #
        # x*y = (xh*2^(n/2)+xl)*(yh*2^(n/2)+yl) = ... =
        #      = xh*yh*2^n  +  (xh*yl + xl*yh)*2^(n/2)  +  xl*yl
        #
        # and let:
        #   x1 = xh*yh, x2 = xh*yl 
        #   x3 = xl*yh, x4 = xl*yl    
        # 
        # Note that in binary, multiplying any number x by 2 to 
        # the power of n gives the same result as bit-shifting x
        # n times to the left. 
        #
        # [ Example: 0001*2^3 = 1000 ]
 		x1 = binary_part(Ah, Bh)
 		x2 = binary_part(Ah, Bl)
 		x3 = binary_part(Al, Bh)
 		x4 = binary_part(Al, Bl)

 		# Acquire len(x2) = len(x3)
 		if len(x2)!=len(x3):
 			while len(x2)<len(x3):
 				# Invariant: value of x2
 				# Variant:  len(x3) - len(x2)
 				x2.insert(0,0)
 			while len(x3)<len(x2):
 				# Invariant: value of x3
 				# Variant: len(x2) - len(x3)
 				x3.insert(0,0)

 		X2X3 = binary_sum(x2,x3)

 		# Bit-shifting x1 to the left
 		for i in range(n):
 			x1.append(0)

 		# Bit-shifting x2 to the left
 		for i in range(n/2):
 			X2X3.append(0)

 		# Acquire len(x4) = len(X2X3)
 		while len(x4)!=len(X2X3):
 			# Invariant: value of x4
 			# Variant: len(X2X3) - len(x4)
 			x4.insert(0,0)

 		X2X3X4 = binary_sum(X2X3, x4)

 		# Acquire len(X2X3X4) = len(x1)
 		while len(X2X3X4)!=len(x1):
 			# Invariant: value of X2X3X4
 			# Variant: len(x1) - len(X2X3X4)
 			X2X3X4.insert(0,0)

 		X1X2X3X4 = binary_sum(X2X3X4, x1)

 		return X1X2X3X4


def binary_sum(x,y):
	'''
    Sig:    int[0..n-1], int[0..n-1] ==> int[0..m-1]
    Pre:    x and y binary arrays of size n
    Post:    Array C containing the binary sum of x and y
    Example:     binary_sum([0,1],[1,1]) = [1,0,0]
    '''

	n = (len(x)+len(y))/2 
	bsum = []
	carry = 0
	x.reverse()
	y.reverse()

	for i in range(n):
		# Invariant: s[0..n]
		# Variant: n - i - 1
		s = x[i] + y[i] + carry
		carry = 0
		if s==0:
			bsum.append(0)
		elif s==1:
			bsum.append(1)
		elif s==2:
			bsum.append(0)
			carry = 1
		else: #s==3
			bsum.append(1)
			carry = 1

	if carry>0:
		bsum.append(1)

	bsum.reverse()

	return bsum
