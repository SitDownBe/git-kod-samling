import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import java.util.ArrayList;

// Frame for the user interface.
public class GoBounce 
  extends JFrame 
  implements ActionListener
{
  
  private ArrayList<BoxWorld> boxList = new ArrayList<BoxWorld>();
  private JButton newB = new JButton("New");
  private JButton closeAll = new JButton("Close all");
  JTextField a = new JTextField("20");
  JTextField b = new JTextField("10");
  JLabel error = new JLabel();
  
  public GoBounce() {
    newB.addActionListener(this);
    closeAll.addActionListener(this);
    
    JPanel dataPart = new JPanel(new GridLayout(4, 2));
    dataPart.add(new JLabel("#Balls"));
    dataPart.add(a); 
    dataPart.add(new JLabel("Delay"));
    dataPart.add(b);
    dataPart.add(newB);
    dataPart.add(closeAll);
    
    JPanel errorPart = new JPanel();
    errorPart.add(error);
    
    this.add(dataPart);
    this.add(errorPart);
    
    setTitle("Let it bounce");
    this.setLayout(new FlowLayout());
    this.setPreferredSize(new Dimension(260,200));
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.pack();
    this.setVisible(true);
  }
  
  // Listens for instructions from the user.
  public void actionPerformed(ActionEvent e) {
    Scanner sca = new Scanner(a.getText());
    Scanner scb = new Scanner(b.getText());
    if (sca.hasNextInt() && scb.hasNextInt()) { 
      if (e.getSource()==newB) {
        int numOfBalls = sca.nextInt();
        int delay = scb.nextInt();
        if (numOfBalls<0 || delay<1) {
          error.setText("Value not allowed.");
        } else {
          boxList.add(new BoxWorld(650,650,delay,numOfBalls));
          error.setText("");
        }
      } else if (e.getSource()==closeAll) {
        error.setText("");
        for (int i=0; i<boxList.size() ;i++) {      
          boxList.get(i).dispose();
        }
      }
    }
  }
  
  public static void main(String[] args) {
    GoBounce goBounce=new GoBounce(); 
  }
  
}