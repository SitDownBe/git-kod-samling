// Immutable class describing vectors. The methods in this class
// return only primitive data types or new objects of type Vector.
// Contains a main method to test the methods of the class.
final public class Vector
{
  
  final private double x; // x-coord.
  final private double y; // y-coord.
  
  // Standard constructor.
  public Vector(double x, double y) {
    this.x=x;
    this.y=y;
  }
  
  public String toString() {
    return "<" + this.x + ", " + this.y + ">"; 
  }
  
  // Returns a new vector equal to v added to this vector.
  public Vector add(Vector v) {
    return new Vector(this.x + v.x, this.y + v.y);
  }
  
  // Returns a new vector equal to v subtracted from this vector.
  public Vector sub(Vector v) {
    return new Vector(this.x - v.x, this.y - v.y); 
  }
  
  // Calculates the dot product between v and this vector.
  public double dot(Vector v) {
    return (this.x * v.x + this.y * v.y); 
  }
  
  // Returns a new vector parallel to this vector, with 
  // a new length determined by d.
  public Vector scale(double d) {
    return new Vector(this.x*d, this.y*d);
  }
  
  // Calculates the distance between v and this vector.
  public double distance(Vector v) {
    double a = Math.pow((this.x-v.x), 2);
    double b = Math.pow((this.y-v.y), 2);
    return Math.sqrt(a+b);
  }
  
  // Calculates the length of this vector.
  public double length() {
    return Math.sqrt(Math.pow(this.x, 2) + Math.pow(this.y, 2)); 
  }
  
  // Returns the x-coord. of this vector.
  public double getX() {
    return this.x; 
  }
  
  // Returns the y-coord. of this vector.
  public double getY() {
    return this.y; 
  }
  
  // Returns a new vector similar to this vector,
  // but with reversed sign of the x-coord.
  public Vector flipSignX() {
    return new Vector(-this.x, this.y); 
  }
  
  //  -||-  y-coord.
  public Vector flipSignY() {
    return new Vector(this.x, -this.y); 
  }
  
  // Returns a new vector with specified length poiting
  // in a random direction.
  public static Vector randomVector(double len) {
    double theta = Math.random()*Math.PI/2;
    return new Vector(len*Math.sin(theta), len*Math.cos(theta));
  }
  
  // Calculates the angle of this vector.
  // Returns angle in radians.
  public double angle() {
    return Math.atan2(this.y, this.x);
  }
  
  // Returns a new vector using polar coord. as argument.
  public static Vector polar(double length, double angle) {
    return new Vector(length*Math.cos(angle), length*Math.sin(angle));
  }
  
  
  // Main method to test class methods.
  public static void main(String[] args) { 
    Vector v1 = new Vector(4,5); // Testing constructor.
    System.out.println("A new vector v1:     " + v1); // Testing toString.
    Vector v2 = new Vector(10,-2);
    System.out.println("Another vector v2:   " + v2);
    System.out.println("v1 plus v2:          " + v1.add(v2)); // Testing add.
    System.out.println("v1 minus v2:         " + v1.sub(v2)); // Testing sub.
    System.out.println("v1 dot v2:           " + v1.dot(v2)); // Testing dot.
    System.out.println("v1 upscaled (2):     " + v1.scale(2.)); // Testing scale.
    System.out.println("Distance v1 to v2:   " + v1.distance(v2)); // Testing distance.
    System.out.println("Length of v1:        " + v1.length()); // Testing length.
    System.out.println("v1 x-coord.:         " + v1.getX()); // Testing getX.
    System.out.println("v1 y-coord.:         " + v1.getY()); // Testing getY.
    System.out.println("v1 flip x:           " + v1.flipSignX()); // Testing flipSignX.
    System.out.println("v1 flip y:           " + v1.flipSignY()); // Testing flipSignY.
    System.out.println("v1 angle:            " + v1.angle() + " (angle in radians defined from y-axis.)"); // Testing angle.
    System.out.println("v2 angle:            " + v2.angle());
    System.out.println("Random vector:       " + randomVector(5) + " (length 5)"); // Testing randomVector. 
    System.out.println("A new vector with");
    System.out.println("angle 1, length 5:   " + polar(5, 1));  // Testing polar.
    System.out.println("Test above vector:   (" + polar(5,1).angle() + " (angle), " + polar(5,1).length() + " (length))");    
  }
}