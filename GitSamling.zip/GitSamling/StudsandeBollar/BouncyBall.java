import java.awt.*;


/* Class describing objects that are contained in a Box.
 * These objects are represented by colorful balls.
 */
public class BouncyBall {
  
  private Vector pos; // position.
  private Vector vel; // velocity.
  private Color c;    // color.
  private int r=15;   // radius.
  private Box theBox; // the Box.
  
  // Constructor that gives the ball a random color.
  public BouncyBall(Vector pos, Vector vel, Box theBox) {
    this.pos=pos;
    this.vel=vel;
    this.theBox=theBox;
    this.c = new Color((float)Math.random(),
                       (float)Math.random(),
                       (float)Math.random());
  }
  
  public String toString() {
    return "" + this.pos + ", " + this.vel;  
  }
  
  // Returns the active radius.
  public int getActiveRadius() {
    return r;
  }
  
  /* Checks the position of the ball to determine
   * whether it should be destroyed or not.
   */
  public boolean checkToAnnihilate() {
    if (this.pos.distance(new Vector(theBox.getWidth()/2,
                                     theBox.getHeight()/2))<r*2-2) {
      return true;
    } else {
      return false;
    }
  }
  
  // Moves the ball one step.
  public void move() {
    this.pos = this.pos.add(this.vel);  // moves the ball to its new position.
    
    if (this.pos.getY()+r>theBox.getHeight() && this.vel.getY()>0 || // bottom wall.
        this.pos.getY()-r<0 && this.vel.getY()<0) { // upper wall.
      
      this.vel = this.vel.flipSignY(); // handles collision with a wall.
      
    }
    
    if (this.pos.getX()+r>theBox.getWidth() && this.vel.getX()>0 || // right wall.
        this.pos.getX()-r<0 && this.vel.getX()<0) { // left wall.
      
      this.vel = this.vel.flipSignX(); // handles collision with a wall.
      
    }
    
  }
  
  // Handles collision with other balls in the Box.
  public void collide(BouncyBall ball) {   
    
    /* Determines the new velocities of two colliding balls,
     * based on a known formula.
     */
    if (this.pos.distance(ball.pos)<=r*2) {
      
      Vector v11=ball.vel.sub(this.vel);
      Vector v12=ball.pos.sub(this.pos);
      double numerator1=v11.dot(v12);
      
      Vector v22=this.vel.sub(ball.vel);
      double numerator2=v12.dot(v22);
      
      double dist=ball.pos.distance(this.pos);
      double denominator=Math.pow(dist, 2);
      
      Vector distPos=ball.pos.sub(this.pos);
      Vector distPos1=distPos.scale(numerator1/denominator);
      Vector distPos2=distPos.scale(numerator2/denominator);
      
      
      this.vel=this.vel.add(distPos1); // new velocity for this ball.
      ball.vel=ball.vel.add(distPos2); // new velocity for the other ball.
    } 
    
    /* Checks if two balls intersect each other and 
     * moves them away from each other until they no
     * longer do.
     */
    while (this.pos.distance(ball.pos)<r*2) {
      Vector v21= this.pos.sub(ball.pos);
      Vector norm= v21.scale(1/v21.length());
      
      this.pos=this.pos.add(norm);
    }
  }
  
  
  // Makes the balls visible for viewing in the Box.
  public void paint(Graphics g) {
    g.setColor(c);
    g.fillOval((int)this.pos.getX()-r, 
               (int)this.pos.getY()-r, 2*r, 2*r);
  }
  
  
}