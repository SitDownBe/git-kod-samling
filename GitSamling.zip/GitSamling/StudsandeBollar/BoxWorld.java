import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

// Frame for the Box.
public class BoxWorld 
  extends JFrame
  implements ActionListener
{
  
  private Box theBox;
  private Timer timer;
  
  public BoxWorld(int width, int height, int delay, int numOfBalls) {
    theBox = new Box(width, height, numOfBalls);
    timer = new Timer(delay, this);
    
    add(theBox);
    
    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    
    pack();
    setVisible(true);
    timer.start();
  }
  
  public void actionPerformed(ActionEvent e) {
    theBox.step();
  }
  
}