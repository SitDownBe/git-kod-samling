import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.ArrayList;

// Class describing the Box in which the balls are contained.
public class Box
  extends JPanel
{
  
  private ArrayList<BouncyBall> balls; // arraylist to keep track of the balls.
  
  public Box(int width, int height, int numOfBalls) { 
    balls = new ArrayList<BouncyBall>();
    
    for (int i=0; i<numOfBalls; i++) { // creates as many balls as the user entered.
      balls.add(new BouncyBall(Vector.randomVector(Math.random()*((height+width)/2)), // position.
                               new Vector(Math.random()*1.5,Math.random()*1.5), this)); // velocity.
    }
    
    /* Determines the visuals of the actual Box.
     */
    this.setPreferredSize(new Dimension(width, height));  
    this.setBackground(Color.white);
    this.setBorder(new LineBorder(Color.black,2));
  }
  
  /* Paints all the components in the Box
   */
  public void paintComponent(Graphics g) {
    
    super.paintComponent(g);
    
    int r=balls.get(0).getActiveRadius();
    g.setColor(new Color(0,0,0)); // a "black hole" where the balls are destroyed upon impact.
    g.fillOval(this.getWidth()/2-r, this.getHeight()/2-r, r*2, r*2);  
    
    for (int i=0; i<balls.size(); i++) {
      balls.get(i).paint(g);
    }
    
  }
  
  /* Checks for collisions and moves the balls forward one step.
   * Also checks for impact with the "black hole".
   */
  public void step() {
    
    for (int i=0; i<balls.size(); i++) {
      for (int j=0; j<balls.size(); j++) {
        if (j!=i){
          balls.get(i).collide(balls.get(j)); // check for collision.
        }
      }
      balls.get(i).move(); // moves one step.
      if (balls.get(i).checkToAnnihilate()) { // checks destruction terms.
        balls.remove(i);
      }
    }
    repaint(); // repaints the new state.
  }
  
}